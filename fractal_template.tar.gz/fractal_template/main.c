#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "fractal.h"

int main()
{
    /* TODO */

    return 0;
}
